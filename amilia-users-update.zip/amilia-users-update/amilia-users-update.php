<?php
/*
Plugin Name: Amelia Users Update
Plugin URI: craig@craigtuckerlcsw.com
Description: Adds existing WordPress users to Amelia Users Table.
Version: 1.0
Author: Criag Tucker
Author URI: craig@craigtuckerlcsw.com
*/
/*
	Copyright 2020	Craig Tucker	(email : craig@craigtuckerlcsw.com)
	GPLv2 Full license details in license.txt
*/

/*
*	Move WordPress user information over to the Amilia User Table.
*/

function coppy_user_information_to_amelia($user_id)
{
	global $wpdb;

	//set the display name
	$user_info = get_userdata($user_id);
	$user_email = $user_info->user_email;
	$first_name = get_user_meta( $user_id, 'first_name', true); 
	$last_name = get_user_meta( $user_id, 'last_name', true);
	$phone_number = get_user_meta( $user_id, 'phone_number', true); 

    if (!in_array('administrator', $user_id->roles) &&
        !in_array('wpamelia-customer', $user_id->roles))		{
		$user = get_user_by('id', $user_id);
		$user->add_role('wpamelia-customer');
        		
		//Add Amelia user
		$wpdb->insert('wp_amelia_users', array(
			'firstName' => $first_name, 
			'lastName' => $last_name, 
			'email' => $user_email, 
			'phone' => $phone_number, 
			'type' => 'customer',
			'externalId' => $user_id
		), array('%s', '%s', '%s', '%s', '%s', '%d'));
	}
}
add_action("user_register", "coppy_user_information_to_amelia", 20);

/*
	Settings Page
*/
function auu_settings_menu_item()
{
	add_options_page('Amelia User Update', 'Amelia User Update', 'manage_options', 'auu_settings', 'auu_settings_page');
}
add_action('admin_menu', 'auu_settings_menu_item', 20);

//affiliates page (add new)
function auu_settings_page()
{
	if(!empty($_REQUEST['updateusers']) && current_user_can("manage_options"))
	{
		global $wpdb;
		$user_ids = $wpdb->get_col("SELECT ID FROM $wpdb->users");
		
		foreach($user_ids as $user_id)
		{
			coppy_user_information_to_amelia($user_id);		 
			set_time_limit(30);			
		}
		
		?>
		<p><?php echo count($user_ids);?> users(s) fixed.</p>
		<?php
	}
	
	?>
	<p>The <em>Amelia Users Update</em> will add all current WordPress users who do not have an administrator Amelia Customer user role to the Amelia User Table. Please click on the button below to update the Amelia User table.</p>
	<p><a href="?page=auu_settings&updateusers=1" class="button-primary">Update Amelia Users Table</a></p>
	<p><strong>WARNING:</strong> This may take a while! If you have a bunch of users or a slow server, <strong>this may hang up or cause other issues with your site</strong>. Use at your own risk.</p>	
	<?php
}
