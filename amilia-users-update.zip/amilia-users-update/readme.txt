=== Amelia Users Update ===
Contributors: Craig Tucker, craig@craigtuckerlcsw.com
Tested on: WP 5.3.2
Version: 1.0

== Description ==

This will take all users who do not have a Administrator user role or who do not yet have an Amelia Customer user role and assigns a customer user role then makes all an Amelia Customer in the Customer's table.

== Installation ==

= Download, Install and Activate! =
1. Upload `Amelia Users Update` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Visit Settings --> Amelia Users Update to run and update of all of your non admin users.


Also the following can be placed in your functions.php file to make all new users Amelia Customers and will automatically load them into the Amelia Customer table.


/**
* After client registration add new role for Amilia.  
* Then add Amilia and Easy Appointment clients to the database.
*/
add_action('wp_login', 'add_users_on_login', 10, 2);
function add_users_on_login($login, $user) {
	global $wpdb;
	$user_info = get_userdata($user->ID);
	$user_email = $user_info->user_email;
	$first_name = get_user_meta( $user->ID, 'first_name', true); 
	$last_name = get_user_meta( $user->ID, 'last_name', true);
	$phone_number = get_user_meta( $user->ID, 'phone_number', true); 
	
    if (!in_array('administrator', $user->roles) &&
        !in_array('wpamelia-customer', $user->roles)) {
        $user->add_role('wpamelia-customer');
		
		//Add Amelia user
		$wpdb->insert('wp_amelia_users', array(
			'firstName' => $first_name, 
			'lastName' => $last_name, 
			'email' => $user_email, 
			'phone' => $phone_number, 
			'type' => 'customer',
			'externalId' => $user->ID
		), array('%s', '%s', '%s', '%s', '%s', '%d'));

    }	
}